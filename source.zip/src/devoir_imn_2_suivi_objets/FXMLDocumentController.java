/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package devoir_imn_2_suivi_objets;

import com.jfoenix.controls.JFXListView;
import com.jfoenix.controls.JFXRadioButton;
import com.jfoenix.controls.JFXTextField;
import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.stage.FileChooser;
import suiviCameraTempsReel.TestOracleTrackingSubtractionMethod;
import suiviObjets.MainSuiviObjets;

/**
 *
 * @author mohammed
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    JFXListView listeChoixCapture;
    @FXML
    Spinner spinMin_BLOB;
    @FXML
    Spinner spinMax_BLOB;
    @FXML
    Spinner spinAccel_Noise_Mag;
    @FXML
    Spinner spinDistance_Threshold;
    @FXML
    Spinner spinMax_skipped_frames;
    @FXML
    Spinner spinMax_Trace_length;
    @FXML
    JFXTextField fieldLearning_Rate;

    @FXML
    JFXRadioButton radioMethode1;
    @FXML
    JFXRadioButton radioMethode2;

    @FXML
    private void handleButtonActionStart(ActionEvent event) throws InterruptedException {
        remplirParametre();

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (radioMethode1.isSelected()) {
                        MainSuiviObjets.main();
                    } else if (radioMethode2.isSelected()) {
                        TestOracleTrackingSubtractionMethod.main();
                    }
                } catch (InterruptedException ex) {
                }
            }
        });
        thread.start();
    }

    //extraire les paramètres et remplir le fichier de configuration
    private void remplirParametre() {
        CONFIG.learningRate = Double.parseDouble(fieldLearning_Rate.getText());;
        CONFIG.MIN_BLOB_AREA = Double.parseDouble(spinMin_BLOB.getEditor().getText());;
        CONFIG.MAX_BLOB_AREA = Double.parseDouble(spinMax_BLOB.getEditor().getText());;
        CONFIG._Accel_noise_mag = Double.parseDouble(spinAccel_Noise_Mag.getEditor().getText());;
        CONFIG._dist_thres = Double.parseDouble(spinDistance_Threshold.getEditor().getText());
        CONFIG._maximum_allowed_skipped_frames = Integer.parseInt(spinDistance_Threshold.getEditor().getText());
        CONFIG._max_trace_length = Integer.parseInt(spinDistance_Threshold.getEditor().getText());

        if (listeChoixCapture.getSelectionModel().getSelectedIndex() == 0) {
            MainSuiviObjets.captureVideoWebcam = true;
            TestOracleTrackingSubtractionMethod.captureVideoWebcam = true;
            FileChooser chooser = new FileChooser();
            chooser.setInitialDirectory(null);
            chooser.setTitle("Ouverture d'un fichier");
            chooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Fichier Video", "*.mp4", "*.avi"));
            File fichier = chooser.showOpenDialog(null);
            if (fichier != null) {
                CONFIG.filename = fichier.getAbsolutePath();
                System.out.println("path:" + fichier.getAbsolutePath());
            }
        } else if (listeChoixCapture.getSelectionModel().getSelectedIndex() == 1) {//Choix de la caméra
            MainSuiviObjets.captureVideoWebcam = false;
            TestOracleTrackingSubtractionMethod.captureVideoWebcam = false;
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        listeChoixCapture.getItems().add(new Label("Lire une vidéo"));
        listeChoixCapture.getItems().add(new Label("Ouvrir la Web Cam"));
        listeChoixCapture.getStyleClass().add("mylistview");

        spinMin_BLOB.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 10000));
        spinMin_BLOB.getEditor().setText("250");
        spinMax_BLOB.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 10000));
        spinMax_BLOB.getEditor().setText("2000");
        spinAccel_Noise_Mag.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 10000));
        spinAccel_Noise_Mag.getEditor().setText("0.5");
        spinDistance_Threshold.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 10000));
        spinDistance_Threshold.getEditor().setText("360");
        spinMax_skipped_frames.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 10000));
        spinMax_skipped_frames.getEditor().setText("10");
        spinMax_Trace_length.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
        spinMax_Trace_length.getEditor().setText("10");
    }

}
