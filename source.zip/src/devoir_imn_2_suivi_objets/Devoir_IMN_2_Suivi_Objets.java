/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package devoir_imn_2_suivi_objets;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 *
 * @author mohammed
 */
public class Devoir_IMN_2_Suivi_Objets extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));

        Scene scene = new Scene(root);

        stage.getIcons().add(new Image(Devoir_IMN_2_Suivi_Objets.class.getResourceAsStream("images/esi.png")));
        scene.getStylesheets().add(Devoir_IMN_2_Suivi_Objets.class.getResource("MiseEnFormeTP1.css").toExternalForm());

        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
