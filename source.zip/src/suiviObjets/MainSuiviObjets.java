package suiviObjets;

import devoir_imn_2_suivi_objets.CONFIG;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.core.MatOfPoint;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import org.opencv.video.BackgroundSubtractorMOG2;
import org.opencv.video.Video;
import org.opencv.videoio.VideoCapture;

/**
 * MainSuiviObjets.java TODO:
 *
 * @author Kim Dinh Son Email:sonkdbk@gmail.com
 */
public class MainSuiviObjets {

    static {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
    }

    static Mat imag = null;//contient le suivi d'objets avec les formes
    static Mat orgin = null;//contient le résultat de l'appicaiton de l'algorithme GMMs (Mélange de Gaussiennes)
    static Mat kalman = null;
    public static Tracker tracker;
    public static boolean captureVideoWebcam;
    public static JFrame jFrame, jFrame2, jFrame3, jFrame4;
    static VideoCapture camera = null;

    public static void main() throws InterruptedException {
        jFrame = new JFrame("SUIVI MULTIPLE D'OBJETS");
        jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        JLabel vidpanel = new JLabel();
        jFrame.setContentPane(vidpanel);
        jFrame.setSize(CONFIG.FRAME_WIDTH, CONFIG.FRAME_HEIGHT);
        jFrame.setLocation((3 / 4)
                * Toolkit.getDefaultToolkit().getScreenSize().width, (3 / 4)
                * Toolkit.getDefaultToolkit().getScreenSize().height);
        jFrame.setVisible(true);

        jFrame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                camera.release();
            }
        });

        // ////////////////////////////////////////////////////////
        jFrame2 = new JFrame("SOUSTRACTION DU FOND STATIQUE");
        jFrame2.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        JLabel vidpanel2 = new JLabel();
        jFrame2.setContentPane(vidpanel2);
        jFrame2.setSize(CONFIG.FRAME_WIDTH, CONFIG.FRAME_HEIGHT);
        jFrame2.setLocation(
                Toolkit.getDefaultToolkit().getScreenSize().width / 2, (3 / 4)
                * Toolkit.getDefaultToolkit().getScreenSize().height);
        jFrame2.setVisible(true);
        // ////////////////////////////////////////////////////////

        // ////////////////////////////////////////////////////////
        jFrame3 = new JFrame("VIDEO en ENTREE");
        jFrame3.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        JLabel vidpanel3 = new JLabel();
        jFrame3.setContentPane(vidpanel3);
        jFrame3.setSize(CONFIG.FRAME_WIDTH, CONFIG.FRAME_HEIGHT);
        jFrame3.setLocation((3 / 4)
                * Toolkit.getDefaultToolkit().getScreenSize().width, Toolkit
                .getDefaultToolkit().getScreenSize().height / 2);
        jFrame3.setVisible(true);
        // ////////////////////////////////////////////////////////

        // ////////////////////////////////////////////////////////
        jFrame4 = new JFrame("FILTRE KALMAN");
        jFrame4.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        JLabel vidpanel4 = new JLabel();
        jFrame4.setContentPane(vidpanel4);
        jFrame4.setSize(CONFIG.FRAME_WIDTH, CONFIG.FRAME_HEIGHT);
        jFrame4.setLocation(
                Toolkit.getDefaultToolkit().getScreenSize().width / 2, Toolkit
                .getDefaultToolkit().getScreenSize().height / 2);
        jFrame4.setVisible(true);
        // ////////////////////////////////////////////////////////

        Mat frame = new Mat();
        Mat outbox = new Mat();
        Mat diffFrame = null;
        Vector<Rect> array = new Vector<Rect>();

        //Créer un fond pour la vidéo à traiter
        BackgroundSubtractorMOG2 mBGSub = Video.createBackgroundSubtractorMOG2();

        tracker = new Tracker((float) CONFIG._dt,
                (float) CONFIG._Accel_noise_mag, CONFIG._dist_thres,
                CONFIG._maximum_allowed_skipped_frames,
                CONFIG._max_trace_length);

        if (captureVideoWebcam) {
            camera = new VideoCapture();
            camera.open(CONFIG.filename);
        } else {
            camera = new VideoCapture(0);
        }

        int i = 0;

        if (!camera.isOpened()) {
            System.out.print("Can not open Camera, try it later.");
            return;
        }

        while (true) {
            if (!camera.read(frame)) {//lire les frames (images) de la vidéo en entrée
                break;
            }
            Imgproc.resize(frame, frame, new Size(CONFIG.FRAME_WIDTH, CONFIG.FRAME_HEIGHT), 0., 0., Imgproc.INTER_LINEAR);
            imag = frame.clone();//copier l'image lue dans imag
            orgin = frame.clone();//copier l'image lue dans orig
            kalman = frame.clone();//copier l'image lue dans kalman
            if (i == 0) {
//                 jFrame.setSize(FRAME_WIDTH, FRAME_HEIGHT);
                //Initialisation du fond statique
                diffFrame = new Mat(outbox.size(), CvType.CV_8UC1);//CV_8UC1: image en niveau de gris
                diffFrame = outbox.clone();
            }

            if (i == 1) {
                diffFrame = new Mat(frame.size(), CvType.CV_8UC1);//CV_8UC1: image en niveau de gris, 
                //appliquer l'algo de mélange de gaussiennes
                processFrame(camera, frame, diffFrame, mBGSub);
                frame = diffFrame.clone();

                //détecter les contours des objets en mouvements
                //contient les rectangles contourant les objets en mouvement
                array = detectionContours(diffFrame);
                //Déclarer un vecteur des points pour dessiner les rectangles de suivi des objets en mouvement
                Vector<Point> detections = new Vector<>();
                //detections.clear();
                Iterator<Rect> it = array.iterator();
                while (it.hasNext()) {
                    Rect obj = it.next();

                    int ObjectCenterX = (int) ((obj.tl().x + obj.br().x) / 2);
                    int ObjectCenterY = (int) ((obj.tl().y + obj.br().y) / 2);

                    Point pt = new Point(ObjectCenterX, ObjectCenterY);
                    detections.add(pt);
                }

                if (array.size() > 0) {//Il y a des points à dessiner
                    //mettre à jour les rectangles de suivi des objets détectés
                    tracker.update(array, detections, imag);
                    tracker.updateKalman(kalman, detections);//--
//                    tracker.updateKalman(imag, detections);
                    Iterator<Rect> it3 = array.iterator();
                    while (it3.hasNext()) {
                        Rect obj = it3.next();

                        int ObjectCenterX = (int) ((obj.tl().x + obj.br().x) / 2);
                        int ObjectCenterY = (int) ((obj.tl().y + obj.br().y) / 2);

                        Point pt = new Point(ObjectCenterX, ObjectCenterY);

                        Imgproc.rectangle(imag, obj.br(), obj.tl(), new Scalar(0, 255, 0), 2);//la couleur du rectangle
                        Imgproc.circle(imag, pt, 1, new Scalar(0, 0, 255), 2);//la couleur cercle
                    }
                } else if (array.size() == 0) {
                }

                for (int k = 0; k < tracker.tracks.size(); k++) {
                    int traceNum = tracker.tracks.get(k).trace.size();
                    if (traceNum > 1) {
                        for (int jt = 1; jt < tracker.tracks.get(k).trace.size(); jt++) {
                            //dessiner la ligne qui suit l'objet détecté en mouvement
                            Imgproc.line(imag,
                                    tracker.tracks.get(k).trace.get(jt - 1),
                                    tracker.tracks.get(k).trace.get(jt),
                                    CONFIG.Colors[tracker.tracks.get(k).track_id % 9], 2, 4, 0);//la couleur de la ligne qui suit l'objet détecté en mouvement
                        }
                    }
                }

                Imgproc.putText(imag, "Entree: " + CONFIG.filename, new Point(20, 360),
                        Core.FONT_HERSHEY_PLAIN, 1,
                        new Scalar(255, 255, 255), 1);
                Imgproc.putText(imag, "Nombre d'objets en mouvement: " + tracker.tracks.size(),
                        new Point(20, 50),
                        Core.FONT_HERSHEY_PLAIN, 1,
                        new Scalar(255, 255, 255), 1);
            }

            i = 1;

            //*****************************************************************************************************/
            //*************************--Mise à jour de l'affichage des images dans les fenêtres*******************/
            //*****************************************************************************************************/
            //la conversion de la structure Mat en une BufferedImage pour l'affichage des images
            ImageIcon image = new ImageIcon(Mat2bufferedImage(imag));
            vidpanel.setIcon(image);
            vidpanel.repaint();
            // temponFrame = outerBox.clone();

            ImageIcon image2 = new ImageIcon(Mat2bufferedImage(frame));
            vidpanel2.setIcon(image2);
            vidpanel2.repaint();

            ImageIcon image3 = new ImageIcon(Mat2bufferedImage(orgin));
            vidpanel3.setIcon(image3);
            vidpanel3.repaint();

            ImageIcon image4 = new ImageIcon(Mat2bufferedImage(kalman));
            vidpanel4.setIcon(image4);
            vidpanel4.repaint();
        }
    }

    // background substractionMOG2
    protected static void processFrame(VideoCapture capture, Mat mRgba/*frame*/, Mat mFGMask/*diffFrame*/, BackgroundSubtractorMOG2 mBGSub) {
        // GREY_FRAME also works and exhibits better performance
        //Mettre à jour le fond statique
        mBGSub.apply(mRgba, mFGMask, CONFIG.learningRate);
        //convertir la couleur de l'image, It converts the image from RGB color space to another.
        Imgproc.cvtColor(mFGMask, mRgba, Imgproc.COLOR_GRAY2BGRA, 0);

        //
        Mat erode = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, new Size(8, 8));
        Mat dilate = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, new Size(8, 8));

        Mat openElem = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, new Size(3, 3), new Point(1, 1));
        Mat closeElem = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, new Size(7, 7), new Point(3, 3));

        //appliquer le suillage pour éliminer les tâches (points qui ne représentent pas les objets en mouvement)
        Imgproc.threshold(mFGMask, mFGMask, 127, 255, Imgproc.THRESH_BINARY);
        //appliquer l'érosion: éliminer les points isolés blancs
        Imgproc.morphologyEx(mFGMask, mFGMask, Imgproc.MORPH_OPEN, erode);
        //appliquer la dilatation: éliminer les poins isolés noirs
        Imgproc.morphologyEx(mFGMask, mFGMask, Imgproc.MORPH_OPEN, dilate);
        //appliquer l'ouverture
        Imgproc.morphologyEx(mFGMask, mFGMask, Imgproc.MORPH_OPEN, openElem);
        //appliquer la fermeture
        Imgproc.morphologyEx(mFGMask, mFGMask, Imgproc.MORPH_CLOSE, closeElem);
    }

    private static BufferedImage Mat2bufferedImage(Mat image) {
        MatOfByte bytemat = new MatOfByte();
        Imgcodecs.imencode(".jpg", image, bytemat);
        byte[] bytes = bytemat.toArray();
        InputStream in = new ByteArrayInputStream(bytes);
        BufferedImage img = null;
        try {
            img = ImageIO.read(in);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return img;
    }

    public static Vector<Rect> detectionContours(Mat outmat) {
        Mat v = new Mat();
        Mat vv = outmat.clone();
        List<MatOfPoint> contours = new ArrayList<MatOfPoint>();
        Imgproc.findContours(vv, contours, v, Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);

        int maxAreaIdx = -1;
        Rect r = null;
        Vector<Rect> rect_array = new Vector<Rect>();

        for (int idx = 0; idx < contours.size(); idx++) {
            Mat contour = contours.get(idx);
            double contourarea = Imgproc.contourArea(contour);
            if (contourarea > CONFIG.MIN_BLOB_AREA && contourarea < CONFIG.MAX_BLOB_AREA) {
                // MIN_BLOB_AREA = contourarea;
                maxAreaIdx = idx;
                r = Imgproc.boundingRect(contours.get(maxAreaIdx));
                rect_array.add(r);
                Imgproc.drawContours(imag, contours, maxAreaIdx, new Scalar(255, 255, 255));
            }
        }

        v.release();
        return rect_array;
    }

}
